var gulp = require('gulp');
var connect = require('gulp-connect');

gulp.task('docs', function() {
  connect.server();
});
